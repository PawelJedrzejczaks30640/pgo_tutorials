import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @org.junit.jupiter.api.Test
    void main() {
    }

    @Test
    void child() {
        int wiek =10;
        int miasto.equals ("Warszawa");
    }
}