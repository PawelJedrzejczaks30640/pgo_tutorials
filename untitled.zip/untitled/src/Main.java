

import java.util.Scanner;
import java.time.*;

public class Main {
    class userdata {
        double wiek = scanner.nextDouble();
        String miasto = scanner.next();
        String dzien = scanner.next();

    }
    class discount {
        int wiek;
        String miasto;
        String dzien;
        int Discount = 0;
        if (wiek <= 10) {
            Discount = 100;
        } else if (wiek <= 18) {
            Discount = 50;
        }

        if (miasto.equals("Warszawa")) {
            Discount += 10;
        }
        if (dzien.equals("Thursday")) {
            Discount = 100;
        }
    }
    class price{
        int cena;
        int Discount;
        double cena = ((40) - (40 * (0.01 * Discount)));
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("podaj wiek");
        double wiek = scanner.nextDouble();
        System.out.println("podaj miasto");
        String miasto = scanner.next();
        System.out.println("podaj dzien tygodnia");
        String dzien = scanner.next();
        LocalDate.now().getDayOfWeek().name();
        int Discount = 0;
        if (wiek <= 10) {
            Discount = 100;
        } else if (wiek <= 18) {
            Discount = 50;
        }

        if (miasto.equals("Warszawa")) {
            Discount += 10;
        }
        if (dzien.equals("Thursday")) {
            Discount = 100;
        }


        double cena = ((40) - (40 * (0.01 * Discount)));


        System.out.println("Data: " + miasto + ", " + " " + wiek + " yeras old, " + " weekday Ticket price: " + cena);
        System.out.println("Disscount: " + Discount + "%");

    }


}




