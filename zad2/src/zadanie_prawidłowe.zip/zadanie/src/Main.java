public class Main {
    public static void main(String[] args) {
        osoba customer = new osoba(29,"Warszawa","Monday");
    }
}